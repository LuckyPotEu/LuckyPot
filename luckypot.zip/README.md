# LuckyPot

Ein kleines React-Projekt für die Verlosungsseite LuckyPot.

## Starten

1. `npm install`
2. `npm start`

## Build

`npm run build`
